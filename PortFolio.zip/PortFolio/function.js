const express = require("express");
const bodyParser = require("body-parser");

const app = express();
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static("public"));
app.use(express.static("public/css/photos"));
app.use(express.static("public/js"));
app.set("view engine", "pug");

function getData() {}

app.get("/index", (req, res) => {
  console.log("hello");
  res.render("index");
});

app.get("/about", (req, res) => {
  res.render("about");
});

app.get(`/project/:id`, (req, res) => {
  var pageNumber = req.params.id - 1;
  var student;
  const fs = require("fs");
  fs.readFile("public/js/data.json", (err, data) => {
    if (err) throw err;
    student = JSON.parse(data);

    res.render("project", { text: student[pageNumber] });
  });
  console.log(student);
});
app.get('*', function (req, res) {
  res.send("<h1>Page not found</h1>");
})

app.listen(3000, () => {
  console.log("Port 3000 is listening");
});
