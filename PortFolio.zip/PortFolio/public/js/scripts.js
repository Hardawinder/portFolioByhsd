$(document).foundation();

$.getJSON("data.json", function (data) {
  jasonArray = data;
  getAlltheValue(data);
});
function getAlltheValue(array1) {
  htmlInTotal = "";

  $.each(array1, function (indexInArray, valueOfElement) {
    htmlInTotal += getCellValue(valueOfElement);
  });
  $(".grid-x.grid-margin-x.small-up-2.medium-up-2.large-up-3").html(
    htmlInTotal
  );
}


function getCellValue(value) {
  return `
<div class="cell">
  <a href=${value.projectLink}>
     <img src=${value.image_urls} >
      <h5>${value.projectname}</h5></a> </div>`;
}
